/* ----------------------------------------------------------------|
| Primer ejercicio del curso de Swift del Tecnológico de Monterrey |
| Alumno: Néstor Barril del Valle.                                 |
| Copyright © 2016 Néstor Barril del Valle. All rights reserved.   |
|-----------------------------------------------------------------*/
 
import UIKit

var numeros = 0...100 //Declaramos un array de 101 posiciones con el rango desde 0 a 100

for i in numeros { //Para cada posicion de ese array vamos a hacer lo siguiente.
    print("\t-\(i)- ")
    if i % 5 == 0 { //vamos a comprobar si es divisible por 5
        print("🎱BINGO‼️ ") //Si lo es, imprimimos Bingo
    }
    if i % 2 == 0 { //Vamos a comprobar si es divisible por 2
    print("Este es un número par")// Si lo es, imprimimos Par
    }else {
    print("Este es un número impar") // Si no lo es, imprimimos Impar
    }
    if i<=40 && i>=30{ // Si la i está comprendida entre el 30 y el 40
        print("🎉Viva Swift🎉") //Imprimimos, además, Viva Swift
        }
}
